(function() {
	"use strict";
	var cryptoGriffinApp = angular.module('cryptoGriffin', ['ngclipboard']);
})();